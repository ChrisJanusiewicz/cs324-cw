#ifndef POINT2F_H
#define POINT2F_H

struct point2f {
    float x;
    float y;

    point2f(float x, float y) {
        this->x = x;
        this->y = y;
    }

};

#endif
